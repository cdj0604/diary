package kr.ac.ansan.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class AppHelpActivity extends Activity{

    public void onCrerate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        TextView textview = new TextView(this);
        textview.setTextSize(20);
        textview.setText("나만의 일기장" + "\n" + "만든이 : 동쥐");
        setContentView(textview);
    }
}